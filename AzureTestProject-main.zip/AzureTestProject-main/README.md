# Documentation

Full documentation is available at https://www.roundthecode.com/dotnet-code-examples/azure-devops-pipeline-example-dotnet-project-ci-cd
