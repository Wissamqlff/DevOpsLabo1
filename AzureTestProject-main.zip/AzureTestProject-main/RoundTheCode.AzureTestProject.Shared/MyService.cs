﻿

namespace RoundTheCode.AzureTestProject.Shared
{
    public class MyService : IMyService
    {
        public bool IsOK()
        {
            return true;
        }
    }
}
